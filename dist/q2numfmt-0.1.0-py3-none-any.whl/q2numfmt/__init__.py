from .core import format_number

# Optional shorthand alias
numfmt = format_number

__all__ = ["format_number", "numfmt"]
